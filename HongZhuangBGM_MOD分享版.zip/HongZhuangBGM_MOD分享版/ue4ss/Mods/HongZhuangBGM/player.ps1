# player.ps1: music player daemon (launched by HongZhuangBGM main.lua at game start)
# Polls Scripts\trigger.play file mtime; on change, plays music\hongzhuang.mp3 from 0 via MCI.
# Exits after 5 consecutive checks with no PBZ.exe process, or after 12 hours.
# Note: player.ps1 lives at MOD root (HongZhuangBGM\player.ps1) -> ONE Split-Path.
# Set env HZBGM_TEST=1 to run without the game (for local testing).

$ErrorActionPreference = "SilentlyContinue"
$modDir = Split-Path -Parent $PSCommandPath
$mp3 = Join-Path $modDir "music\hongzhuang.mp3"
$trigger = Join-Path $modDir "Scripts\trigger.play"
$logfile = Join-Path $modDir "player.log"

function L($m) { Add-Content -Path $logfile -Value ("[{0}] {1}" -f (Get-Date -Format 'HH:mm:ss.fff'), $m) }

L "watcher start"
L "mp3=$mp3"
L "trigger=$trigger"
if (-not (Test-Path $mp3)) { L "ERROR: mp3 file missing"; exit 1 }

Add-Type -Namespace WinMM -Name MCI -MemberDefinition @"
[DllImport("winmm.dll")] public static extern int mciSendString(string cmd, System.Text.StringBuilder ret, int len, System.IntPtr cb);
"@ | Out-Null

$sb = New-Object System.Text.StringBuilder 256
$alias = "hzbm"

$lastWrite = $null
$missCount = 0
$sw = [System.Diagnostics.Stopwatch]::StartNew()

# Volume config: volume.txt in MOD dir, 0-100 (default 100). Re-read on every playback,
# so you can edit it while the game is running.
$volFile = Join-Path $modDir "volume.txt"

function Get-Volume {
    $v = 100
    if (Test-Path $volFile) {
        $raw = (Get-Content $volFile -TotalCount 1 -ErrorAction SilentlyContinue)
        $n = 0
        if ([int]::TryParse("$raw".Trim(), [ref]$n)) { $v = $n }
    }
    if ($v -lt 0) { $v = 0 }
    if ($v -gt 100) { $v = 100 }
    return $v
}

while ($true) {
    Start-Sleep -Milliseconds 120

    if ($env:HZBGM_TEST -ne "1") {
        if (-not (Get-Process "PBZ" -ErrorAction SilentlyContinue)) {
            $missCount++
            if ($missCount -ge 5) { L "PBZ.exe gone, exit"; break }
        } else { $missCount = 0 }
    }
    if ($sw.Elapsed.TotalHours -gt 12) { break }

    if (-not (Test-Path $trigger)) { continue }
    $w = (Get-Item $trigger).LastWriteTimeUtc.Ticks
    if ($lastWrite -eq $null) { $lastWrite = $w; continue }
    if ($w -ne $lastWrite) {
        $lastWrite = $w
        $v = Get-Volume
        $mciVol = $v * 10   # MCI volume range: 0-1000
        $rc1 = [WinMM.MCI]::mciSendString("close $alias", $sb, 256, [System.IntPtr]::Zero)
        $rc2 = [WinMM.MCI]::mciSendString('open "' + $mp3 + '" type mpegvideo alias ' + $alias, $sb, 256, [System.IntPtr]::Zero)
        $rc4 = [WinMM.MCI]::mciSendString("setaudio $alias volume to $mciVol", $sb, 256, [System.IntPtr]::Zero)
        $rc3 = [WinMM.MCI]::mciSendString("play $alias from 0", $sb, 256, [System.IntPtr]::Zero)
        L ("PLAY close=$rc1 open=$rc2 vol=$rc4 play=$rc3 (0=ok) volume=$v%")
    }
}
[WinMM.MCI]::mciSendString("close $alias", $sb, 256, [System.IntPtr]::Zero) | Out-Null
L "watcher end"
