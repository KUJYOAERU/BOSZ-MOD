-- =====================================================================
-- HongZhuangBGM v10 - 红妆鬼斩绝技BGM MOD (影之刃零)
-- v10 方案: 从 ASC (原生类, FindFirstOf 可用) 枚举已授予技能实例
--   1. FindFirstOf 找 ASC (原生类搜索已验证可用)
--   2. ASC.ActivatableAbilities.Items = 已授予技能列表
--      每项 .Ability 是技能实例 (或CDO), GetClass():GetFullName()
--      即蓝图类的 /Game/ 完整路径!
--   3. 对类名以 _C_C 结尾的战技类: RegisterHook(路径:K2_ActivateAbility)
--      → 红妆鬼斩绝技释放时回调 → 放歌
--   注: 本定制UE4SS的 FindFirstOf 对BP类损坏(返回无效对象),
--       但对原生类正常, 故以 ASC 为跳板。
-- =====================================================================

local MOD_DIR = nil
do
    local info = debug.getinfo(1, "S")
    if info and info.source and info.source:sub(1, 1) == "@" then
        MOD_DIR = info.source:sub(2):match("^(.*)[/\\]Scripts[/\\]main%.lua$")
    end
    if not MOD_DIR then MOD_DIR = "." end
end

local TRIGGER_FILE = MOD_DIR .. "\\Scripts\\trigger.play"
local P = "[HZBGM]"

local function log(...)
    print(P, ...)
end

log("v11 loaded (FINAL), MOD_DIR =", MOD_DIR)

-- ---------- 手动测试热键 ----------
RegisterKeyBind(0x78, function() -- F9
    local f = io.open(TRIGGER_FILE, "w")
    if f then f:write("manual"); f:close() end
    log("F9 manual trigger written")
end)

-- ---------- 音乐触发 (2 秒冷却) ----------
local lastFire = 0
local function fireMusic(reason)
    local now = os.clock()
    if now - lastFire < 2 then return end
    lastFire = now
    local f = io.open(TRIGGER_FILE, "w")
    if f then
        f:write(tostring(os.time()))
        f:close()
        log("MUSIC FIRED:", reason)
    else
        log("ERROR: write trigger failed")
    end
end

-- ---------- 启动音乐守护进程 ----------
LoopAsync(1000, function()
    if os and type(os.execute) == "function" then
        local ps1 = MOD_DIR .. "\\player.ps1"
        local cmd = 'start "" /min powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' .. ps1 .. '"'
        local ok, err = pcall(os.execute, cmd)
        log("watcher launch:", ok, err or "")
    end
    return true
end)

-- ---------- ASC 获取 (原生类, 多候选) ----------
local ASC_CLASSES = { "PBZAbilitySystemComponent", "AbilitySystemComponent", "PBZASC" }
local ascCache = nil

local function getASC()
    local ok, v = pcall(function()
        if ascCache and ascCache:IsValid() then return ascCache end
        return nil
    end)
    if ok and v then return v end
    for _, cn in ipairs(ASC_CLASSES) do
        local ok2, a = pcall(FindFirstOf, cn)
        if ok2 and a and a:IsValid() then
            ascCache = a
            log("ASC found:", cn)
            return a
        end
    end
    return nil
end

-- ---------- 技能路径收集 + 战技 hook ----------
local hookedClasses = {}
local seenClasses = {}

-- ---------- 白名单: 只在这些战技类激活时放歌 ----------
-- GA_Hun_GuiTouBlade_C_C = 红妆鬼斩 (鬼头刀) 的绝技, 实测确认
local MUSIC_CLASSES = {
    ["GA_Hun_GuiTouBlade_C_C"] = true,
}

local function tryHookAbilityClass(clsObj, clsName, fullName)
    if hookedClasses[clsName] then return end
    local okh, err = pcall(function()
        RegisterHook(fullName .. ":" .. "K2_ActivateAbility",
            function(self, ...)
                if MUSIC_CLASSES[clsName] then
                    fireMusic("CombatArt " .. clsName)
                else
                    log("CA activated (not whitelisted):", clsName)
                end
            end)
    end)
    log("hook", clsName, ":", okh, err or "")
    if okh then hookedClasses[clsName] = true end
end

local function scanASC()
    local asc = getASC()
    if not asc then return end

    -- 读 ActivatableAbilities.Items 数组
    local okA, container = pcall(function() return asc.ActivatableAbilities end)
    if not okA or not container then
        if scanCount % 10 == 1 then log("ASC has no ActivatableAbilities property") end
        return
    end

    local okI, items = pcall(function() return container.Items end)
    if not okI or not items then
        if scanCount % 10 == 1 then log("container has no Items") end
        return
    end

    -- 数组长度: 多种方式尝试
    local n = nil
    pcall(function() n = items.NumLength end)
    if not n or n == 0 then pcall(function() n = #items end) end
    if not n or n == 0 then pcall(function() n = items:GetArrayNum() end) end

    if n and n > 0 then
        for i = 0, n - 1 do
            local okS, spec = pcall(function() return items[i] end)
            if okS and spec then
                local okAb, ab = pcall(function() return spec.Ability end)
                if okAb and ab then
                    local okN, clsName = pcall(function() return ab:GetClass():GetFName():ToString() end)
                    if okN and clsName and not seenClasses[clsName] then
                        seenClasses[clsName] = true
                        local okF, fullName = pcall(function() return ab:GetClass():GetFullName() end)
                        if okF and fullName then
                            log("GRANTED:", clsName, "|", fullName)
                            -- 战技类: _C_C 结尾 → hook 激活
                            if clsName:sub(-4) == "_C_C" then
                                tryHookAbilityClass(ab, clsName, fullName)
                            end
                        end
                    end
                end
            end
        end
    elseif scanCount % 10 == 1 then
        log("ASC items length unreadable or 0, raw:", tostring(n), tostring(items))
    end
end

-- 游戏线程轮询扫描 (2 秒一次)
local scanCount = 0
LoopInGameThreadWithDelay(2000, function()
    scanCount = scanCount + 1
    scanASC()
end)

-- ---------- 辅助: 原生事件通道 (已验证可用) ----------
local gevSeenTags = {}
pcall(function()
    RegisterHook("/Script/GameplayAbilities.AbilitySystemBlueprintLibrary:SendGameplayEventToActor",
        function(...)
            local tag = nil
            for i = 1, select("#", ...) do
                local p = select(i, ...)
                local oku, u = pcall(function() return p:get() end)
                if oku and u then
                    local okt, t = pcall(function() return u.EventTag.TagName:ToString() end)
                    if okt and t and t ~= "" and t ~= "None" then tag = t end
                end
            end
            if tag and not gevSeenTags[tag] then
                gevSeenTags[tag] = true
                log("GAMEPLAY_EVENT:", tag)
            end
        end)
end)

log("v11 FINAL - whitelist mode (only GuiTouBlade)")
